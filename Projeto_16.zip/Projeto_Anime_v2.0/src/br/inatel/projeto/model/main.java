package br.inatel.projeto.model;

import br.inatel.projeto.dao.MangaDAO;
import java.util.ArrayList;

/**
 *
 * @author Moises Delmoro
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          br.inatel.projeto.view.Login log = new br.inatel.projeto.view.Login();
          log.setVisible(true);
        
    }

}
